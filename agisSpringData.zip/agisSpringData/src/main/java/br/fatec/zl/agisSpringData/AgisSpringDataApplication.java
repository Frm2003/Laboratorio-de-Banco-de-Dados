package br.fatec.zl.agisSpringData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgisSpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgisSpringDataApplication.class, args);
	}

}

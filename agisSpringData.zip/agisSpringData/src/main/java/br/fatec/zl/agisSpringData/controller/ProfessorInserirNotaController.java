package br.fatec.zl.agisSpringData.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.fatec.zl.agisSpringData.model.Materia;
import br.fatec.zl.agisSpringData.model.Matricula;
import br.fatec.zl.agisSpringData.services.MateriaService;
import br.fatec.zl.agisSpringData.services.MatriculaService;
import jakarta.servlet.http.HttpServletResponse;


@Controller
@RequestMapping("/professorInseriNota")
public class ProfessorInserirNotaController {
	@Autowired
	private MateriaService mserv;
	
	@Autowired
	private MatriculaService matserv;
	
	private List<Matricula> matriculas = new ArrayList<>();
	private List<Materia> materias = new ArrayList<>();
	
	@GetMapping
	public String get(ModelMap model) {
		if (!materias.isEmpty()) { materias.removeAll(materias); }
		
		materias.addAll(mserv.buscarTudo());
		model.addAttribute("materias", materias);
		
		return "professorInseriNota";
	}
	
	@PostMapping
	public String post(@RequestParam Map<String, String> param, ModelMap model, HttpServletResponse response) {
		String codMateria = param.get("codMateria");
		
		switch (param.get("botao")) {
		case "Buscar matriculas":
			if (!matriculas.isEmpty()) { matriculas.removeAll(matriculas); }
			
			matriculas.addAll(matriculasMaterias(Long.parseLong(codMateria)));
			model.addAttribute("tipoAvalicao", matriculas.get(0).getMateria().getTipoAvalicao());
			break;
		case "Aplicar Nota": 
			String ra = param.get("ra");
			String tipoAvalicao = param.get("tipoAvalicao");
			
			float p1 = Float.parseFloat(param.get("p1"));
			float p2 = Float.parseFloat(param.get("p2"));
			float p3 = Float.parseFloat(param.get("t"));
			
			inseriNota(ra, Long.parseLong(codMateria), tipoAvalicao, p1, p2, p3);
			
			break;
		}
		
		model.addAttribute("matriculas", matriculas);
		model.addAttribute("materias", materias);
		
		return "professorInseriNota";
	}

	private void inseriNota(String ra, Long codMateria, String tipoAvalicao, float ... notas) {
		for (Matricula matri : matserv.buscarTudo()) {
			if (matri.getAluno().getRa().equals(ra) && matri.getMateria().getCod() == codMateria) {
				
				float[] pesos = new float[3];
				
				if (tipoAvalicao.equals("Tipo1")) {
					pesos[0] = (float) 0.3;
					pesos[1] = (float) 0.5;
					pesos[2] = (float) 0.2;
				} else if (tipoAvalicao.equals("Tipo2")) {
					pesos[0] = (float) 0.35;
					pesos[1] = (float) 0.35;
					pesos[2] = (float) 0.3;
				} else if (tipoAvalicao.equals("Tipo3")) {
					pesos[0] = (float) 0.33;
					pesos[1] = (float) 0.33;
					pesos[2] = (float) 0.33;
				} else {
					pesos[0] = (float) 0.8;
					pesos[1] = (float) 0.2;
				}
				
				float notaFinal = calculaNota(pesos, notas);
				
				
				if (notaFinal >= 6) {
					matri.setSituacao("aprovado");
					matri.setAprovado(true);
				} else if (notaFinal >= 3) {
					matri.setSituacao("em exame");
					matri.setAprovado(false);
				} else {
					matri.setSituacao("reprovado");
					matri.setAprovado(false);
				}
				
				matri.setNota1(notas[0]);
				matri.setNota2(notas[1]);
				matri.setNota3(notas[2]);
				matri.setNota(notaFinal);
				
				matserv.atualizar(matri);
				break;
			}
		}
	}
	
	private List<Matricula> matriculasMaterias(Long codMateria) {
		for (Materia m : materias) {
			if (m.getCod() == codMateria) {
				return matserv.listaMatriculasMateria(m);
			}
		}
		return null;
	}
	
	private float calculaNota(float[] pesos, float ... notas) {
		float soma = 0;
		
		for (int i = 0; i < notas.length; i++) {
			soma += notas[i] * pesos[i];
		}
		
		return soma;
	}
}

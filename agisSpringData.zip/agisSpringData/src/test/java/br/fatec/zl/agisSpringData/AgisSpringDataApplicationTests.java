package br.fatec.zl.agisSpringData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgisSpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
